﻿$("#cb").click(function () {
    showTableContent('Order_item');
});

$("#add").click(function () {
    add();
});

$("#pb").click(function () {
    doPrint();
});
/*
读取json文件
*/

window.onload = function () {
    var url = "data/data.json"/*json文件url，本地的就写本地的位置，如果是服务器的就写服务器的路径*/
    var request = new XMLHttpRequest();
    request.open("get", url);/*设置请求方法与路径*/
    request.send(null);/*不发送数据到服务器*/
    request.onload = function () {/*XHR对象获取到返回信息后执行*/
        if (request.status == 200) {/*返回状态为200，即为数据获取成功*/
            var json = JSON.parse(request.responseText);
            for(var i=0;i<json.length;i++){
                console.log(json[i].name);
            }
            console.log("加载json文件...");
            console.log(json);
            document.getElementById('Print_payee').value = json.order.operator;
            document.getElementById('Print_hotel').value = json.hotel_info.name; //酒店名称
            document.getElementById('Print_address').value = json.hotel_info.address; //酒店地址
            document.getElementById('Print_num').value = json.hotel_info.number; //酒店编号 + 账号
            document.getElementById('Print_phone').value = json.hotel_info.phone; //酒店电话
            document.getElementById('Print_zip').value = json.hotel_info.zip; //酒店邮编
            document.getElementById('Print_fex').value = json.hotel_info.fex; //酒店传真
            console.log("json获取成功...");
            $().toastmessage('showSuccessToast', "已加载配置文件...");
            
        }else{
            console.log("json文件不存在...");
            $().toastmessage('showNoticeToast', "json文件不存在...");
            document.getElementById('Modal_title').innerHTML = '浏览器无法正确读取配置文件';
            document.getElementById("Modal_body").innerHTML = '<p>检查根目录 <code>data/data.json</code> 文件是否存在。</p><p>检查是否从根目录 <code>启动.exe</code> 程序启动。</p><p>如果无法解决，可以手动输入账单基础信息。</p><div class="alert alert-primary" role="alert">正确的浏览地址：<br><a href="http://localhost/">localhost</a> 、<a href="http://127.0.0.1/">127.0.0.1</a></div>';
            $('#Modal').modal('show');
        }
    }
}

/*
    打印
*/

function doPrint() {
    bdhtml = window.document.body.innerHTML;
    sprnstr = "<!--startprint-->";//打印顶部
    eprnstr = "<!--endprint-->";//打印底部
    prnhtml = bdhtml.substr(bdhtml.indexOf(sprnstr) + 17);
    prnhtml = prnhtml.substring(0, prnhtml.indexOf(eprnstr));
    window.document.body.innerHTML = prnhtml;
    window.print();
    console.log("打印一波...");
    $().toastmessage('showNoticeToast', "打印一波...");
    location.reload();
}

POWERMODE.colorful = true; // make power mode colorful
POWERMODE.shake = false; // turn off shake
document.body.addEventListener('input', POWERMODE);
var payeee = "";
if(document.getElementById('Print_payee').value == "" || undefined || null){
    payeee = "小闫同学";
}else{
    payeee = document.getElementById('Print_payee').value;
}
$('.bg').watermark({
    texts: ["结账单制作", "https://psmtool.153700.xyz/", "小闫"], //水印文字
    textColor: "#e9ecef", //文字颜色
    textFont: '16px 微软雅黑', //字体
    width: 200, //水印文字的水平间距
    height: 80,  //水印文字的高度间距（低于文字高度会被替代）
    textRotate: -30 //-90到0， 负数值，不包含-90
});

/*
 
    日期增加
 
*/
function addDay(datetime, days) {
    var old_time = new Date(datetime.replace(/-/g, "/")); //替换字符，js不认2013-01-31,只认2013/01/31
    var fd = new Date(old_time.valueOf() + days * 24 * 60 * 60 * 1000); //日期加上指定的天数
    var new_time = fd.getFullYear() + "-";
    var month = fd.getMonth() + 1;
    if (month >= 10) {
        new_time += month + "-";
    } else {
        //在小于10的月份上补0
        new_time += "0" + month + "-";
    }
    if (fd.getDate() >= 10) {
        new_time += fd.getDate();
    } else {
        //在小于10的日期上补0
        new_time += "0" + fd.getDate();
    }
    return new_time; //输出格式：2013-01-02
};
/*
    编辑框日期选择
*/
$(document).ready(function () {
    $('#Print_time').dcalendarpicker({
        format: 'yyyy-mm-dd'
    });
    $('#Item_time').dcalendarpicker({
        format: 'yyyy-mm-dd'
    });
    console.log("日期组件加载...");
});
/** 
 * 遍历表格内容返回数组
 * @param Int  id 表格id
 * @return Array
 */
function getTableContent(id) {
    var ldate = '';
    var mytable = document.getElementById(id);
    var data = [];
    for (var i = 0, rows = mytable.rows.length; i < rows; i++) {
        for (var j = 0, cells = mytable.rows[i].cells.length; j < cells; j++) {
            if (!data[i]) {
                data[i] = new Array();
            }
            data[i][j] = mytable.rows[i].cells[j].innerHTML;
        }
    }
    return data;
};
/** 
 * 输出房账表格内容
 * @param Int  id 表格id
 */
function showTableContent(id) {
    var data = getTableContent(id);
    var tmp = '';
    var sum = 0;
    var fdate = '';
    var ldate = '';
    for (i = 0, rows = data.length; i < rows; i++) {
        tmp += '<tr>';
        for (j = 0, cells = (data[i].length - 1); j < cells; j++) {
            tmp += '<td>' + data[i][j] + '</td>';
        }
        tmp += '</tr>';
        sum = sum + parseFloat(data[i][2]); //房账循环累计金额
        fdate = data[0][0];//第一个房账的第一个日期
        ldate = data[data.length - 1][0]; //倒数第一个房账的第一个日期
    }
    document.getElementById('Order_hotel').innerText = document.getElementById('Print_hotel').value; //酒店名称
    document.getElementById('Order_num').innerText = 'B' + document.getElementById('Print_num').value + Math.random().toString().slice(-8) + '001'; //酒店编号 + 账号
    document.getElementById('Order_name').innerText = document.getElementById('Print_name').value; //客人姓名
    document.getElementById('Order_room').innerText = document.getElementById('Item_room').value; //房间号
    document.getElementById('Order_cdate').innerText = fdate; //入住日期
    document.getElementById('Order_ldate').innerText = addDay(ldate, 1); //离店日期
    document.getElementById('Order_ptime').innerText = document.getElementById('Print_time').value; //打印日期
    document.getElementById('Order_payee').innerText = document.getElementById('Print_payee').value; //收款人
    document.getElementById('Order_fdate').innerText = fdate; //收费日期
    document.getElementById('Order_pay').innerText = document.getElementById('Item_pay').value; //支付方式
    document.getElementById('Order_sum1').innerText = sum; //付款合计
    document.getElementById('Order_sum3').innerText = sum; //付款合计
    document.getElementById('Order_print_item').innerHTML = tmp; //房账
    document.getElementById('Order_sum2').innerText = sum; //消费合计
    document.getElementById('Order_address').innerText = document.getElementById('Print_address').value; //酒店地址
    document.getElementById('Order_phone').innerText = document.getElementById('Print_phone').value; //酒店电话
    document.getElementById('Order_zip').innerText = document.getElementById('Print_zip').value; //酒店邮编
    document.getElementById('Order_fex').innerText = document.getElementById('Print_fex').value; //酒店传真
    console.log("结账单信息导入成功...");
    $().toastmessage('showSuccessToast', "结账单信息导入成功...");
    return ldate;
};
var num = 0;
function add() {
    var tr = document.createElement('tr');
    var td1 = document.createElement('td');
    var td2 = document.createElement('td');
    var td3 = document.createElement('td');
    var td4 = document.createElement('td');
    num++;
    var xy_money = 10;
    xy_money = num * xy_money;
    if (document.getElementById('Item_time').value == "" || undefined || null) {
        td1.innerHTML = '<span style="color:#f00">晓燕姐给</span>'; //错误输出
        console.log("日期未选择...");
    } else {
        td1.innerHTML = document.getElementById('Item_time').value;
        document.getElementById('Item_time').value = addDay(document.getElementById('Item_time').value, 1);
    };
    if (document.getElementById('Item_room').value == "" || undefined || null) {
        td2.innerHTML = '<span style="color:#f00">陌生人</span>';//错误输出
        console.log("房间号未输入...");
    } else {
        td2.innerHTML = document.getElementById('Fee_Type').value + document.getElementById('Item_room').value;
    };
    if (document.getElementById('Item_money').value == "" || undefined || null) {
        if (xy_money < 50) {
            td3.innerHTML = '<span style="color:#f00">帮忙付了' + xy_money + '块</span>';//错误输出
            console.log("金额未输入...");
        } else {
            td1.innerHTML = '<span style="color:#f00">晓燕姐她</span>';//错误输出
            td2.innerHTML = '<span style="color:#f00">破产了</span>';//错误输出
            td3.innerHTML = '<span style="color:#f00">没钱跑路!</span>';//错误输出
            console.log("连点超过4次...");
        }
    } else {
        td3.innerHTML = document.getElementById('Item_money').value;
    };
    td4.innerHTML = '<button type="button" class="btn btn-danger btn-sm" onclick="del(this);">删除</button>';
    var table = document.getElementById('Order_item');
    table.appendChild(tr);
    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    $(".app-table").animate({
        scrollTop: $('.app-table')[0].scrollHeight - $('.app-table')[0].clientHeight   //新增房账项目，超出高度动画置底
    }, 300);
    console.log("添加了一项房费...");
    $().toastmessage('showNoticeToast', "添加了一项房费...");
    
};
/*
    创建删除函数
*/
function del(x) {//此处不能写成remove(x),js中remove()方法用于从下拉列表删除选项。
    var tr = x.parentNode.parentNode;
    tr.parentNode.removeChild(tr);
    console.log("删除了一项房费...");
    $().toastmessage('showErrorToast', "删除了一项房费...");
};